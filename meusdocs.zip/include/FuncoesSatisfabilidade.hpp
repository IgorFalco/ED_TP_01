#pragma once
#include <iostream>
#include <bits/stdc++.h>
#include "Arvore.hpp"
using namespace std;

namespace FuncoesSatisfabilidade
{
    std::string AvaliacaoDeSatisfabilidade(std::string formula, std::string stringDeAnalise);
}
